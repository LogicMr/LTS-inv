-- Update System to Use Only TSh Currency
-- This script will remove all other currencies and set TSh as the only currency

-- First, set TSh as the default currency
UPDATE currencies SET is_default = TRUE WHERE code = 'TZS';

-- Update all products to use TSh currency first (to avoid foreign key issues)
UPDATE products SET currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1) WHERE currency_id IS NOT NULL AND currency_id != (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

-- Update all sales to use TSh currency
UPDATE sales SET currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1) WHERE currency_id IS NOT NULL AND currency_id != (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

-- Update all purchases to use TSh currency  
UPDATE purchases SET currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1) WHERE currency_id IS NOT NULL AND currency_id != (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

-- Update sale_items to use TSh currency if it has currency_id field
UPDATE sale_items SET currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1) WHERE currency_id IS NOT NULL AND currency_id != (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

-- Update purchase_items to use TSh currency if it has currency_id field
UPDATE purchase_items SET currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1) WHERE currency_id IS NOT NULL AND currency_id != (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

-- Set exchange rate to 1.0 for TSh (since it's now the only currency)
UPDATE currencies SET exchange_rate = 1.000000 WHERE code = 'TZS';

-- Now safely remove all other currencies (keep only TSh)
DELETE FROM currencies WHERE code != 'TZS';

-- Verify the changes
SELECT '=== CURRENCY UPDATE COMPLETE ===' as status;
SELECT 'Currencies after update:' as info;
SELECT * FROM currencies ORDER BY is_default DESC, code;

SELECT 'Products using TSh:' as info;
SELECT COUNT(*) as count FROM products WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

SELECT 'Sales using TSh:' as info;
SELECT COUNT(*) as count FROM sales WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);

SELECT 'Purchases using TSh:' as info;
SELECT COUNT(*) as count FROM purchases WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS' LIMIT 1);
SELECT '=== CURRENCY UPDATE COMPLETE ===' as status;
SELECT 'Currencies after update:' as info;
SELECT * FROM currencies;

SELECT 'Products using TSh:' as info;
SELECT COUNT(*) as count FROM products WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS');

SELECT 'Sales using TSh:' as info;
SELECT COUNT(*) as count FROM sales WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS');

SELECT 'Purchases using TSh:' as info;
SELECT COUNT(*) as count FROM purchases WHERE currency_id = (SELECT id FROM currencies WHERE code = 'TZS');
