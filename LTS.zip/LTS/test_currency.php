<?php
/**
 * Test Currency Functionality
 * This script tests the multi-currency features
 */
require_once 'config/config.php';

echo "<h2>Currency Functionality Test</h2>";

// Test currency functions
echo "<h3>Available Currencies:</h3>";
$currencies = getCurrencies();
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>Code</th><th>Name</th><th>Symbol</th><th>Rate</th><th>Default</th><th>Test Format</th></tr>";
foreach ($currencies as $currency) {
    $testAmount = 100.50;
    $formatted = formatCurrency($testAmount, $currency['id']);
    echo "<tr>";
    echo "<td>{$currency['code']}</td>";
    echo "<td>{$currency['name']}</td>";
    echo "<td>{$currency['symbol']}</td>";
    echo "<td>" . number_format($currency['exchange_rate'], 6) . "</td>";
    echo "<td>" . ($currency['is_default'] ? 'Yes' : 'No') . "</td>";
    echo "<td>$formatted</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h3>Currency Conversion Test:</h3>";
$defaultCurrency = getDefaultCurrency();
if ($defaultCurrency) {
    echo "<p>Default Currency: {$defaultCurrency['code']} ({$defaultCurrency['name']})</p>";
    
    // Test conversion between currencies
    $testAmount = 100;
    foreach ($currencies as $fromCurrency) {
        foreach ($currencies as $toCurrency) {
            if ($fromCurrency['id'] != $toCurrency['id']) {
                $converted = convertCurrency($testAmount, $fromCurrency['id'], $toCurrency['id']);
                $fromFormatted = formatCurrency($testAmount, $fromCurrency['id']);
                $toFormatted = formatCurrency($converted, $toCurrency['id']);
                echo "<p>{$fromFormatted} = {$toFormatted}</p>";
            }
        }
        break; // Just show first conversion to avoid too much output
    }
}

echo "<h3>Product Currency Test:</h3>";
$products = fetchAll("SELECT p.*, cur.code as currency_code, cur.symbol as currency_symbol 
                     FROM products p 
                     LEFT JOIN currencies cur ON p.currency_id = cur.id 
                     LIMIT 5");

if (count($products) > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Product</th><th>Cost Price</th><th>Selling Price</th><th>Currency</th></tr>";
    foreach ($products as $product) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($product['name']) . "</td>";
        echo "<td>" . formatCurrency($product['cost_price'], $product['currency_id']) . "</td>";
        echo "<td>" . formatCurrency($product['selling_price'], $product['currency_id']) . "</td>";
        echo "<td>{$product['currency_code']} ({$product['currency_symbol']})</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No products found. <a href='manager/products.php'>Add some products</a></p>";
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ul>";
echo "<li><a href='setup_currency.php'>Setup Currency Database</a> (if not done yet)</li>";
echo "<li><a href='admin/currencies.php'>Manage Currencies</a> (update exchange rates)</li>";
echo "<li><a href='manager/products.php'>Add Products with Currency</a></li>";
echo "<li><a href='test_product_add.php'>Test Product Addition</a></li>";
echo "</ul>";

echo "<hr>";
echo "<p><a href='index.php'>Back to System</a></p>";
?>
