<?php
/**
 * Quick Currency Test
 * Simple test to verify currency functions are working
 */
require_once 'config/config.php';
require_once 'includes/currency.php';

echo "<h2>Quick Currency Test</h2>";

try {
    // Test getCurrencies function
    echo "<h3>Testing getCurrencies():</h3>";
    $currencies = getCurrencies();
    echo "<p>Found " . count($currencies) . " currencies</p>";
    
    if (count($currencies) > 0) {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>Code</th><th>Name</th><th>Symbol</th><th>Default</th></tr>";
        foreach ($currencies as $currency) {
            echo "<tr>";
            echo "<td>{$currency['code']}</td>";
            echo "<td>{$currency['name']}</td>";
            echo "<td>{$currency['symbol']}</td>";
            echo "<td>" . ($currency['is_default'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Test getDefaultCurrency function
    echo "<h3>Testing getDefaultCurrency():</h3>";
    $defaultCurrency = getDefaultCurrency();
    if ($defaultCurrency) {
        echo "<p>Default currency: {$defaultCurrency['code']} ({$defaultCurrency['symbol']})</p>";
    } else {
        echo "<p style='color: red;'>No default currency found</p>";
    }
    
    // Test formatCurrency function
    echo "<h3>Testing formatCurrency():</h3>";
    $testAmount = 100.50;
    foreach ($currencies as $currency) {
        if ($currency['is_active']) {
            $formatted = formatCurrency($testAmount, $currency['id']);
            echo "<p>{$currency['code']}: $formatted</p>";
        }
    }
    
    // Test getCurrencySelectOptions function
    echo "<h3>Testing getCurrencySelectOptions():</h3>";
    echo "<select>";
    echo getCurrencySelectOptions();
    echo "</select>";
    
    echo "<hr>";
    echo "<p style='color: green;'>✅ All currency functions are working!</p>";
    
    echo "<h3>Next Steps:</h3>";
    echo "<ul>";
    echo "<li><a href='manager/products.php'>Test Product Management</a></li>";
    echo "<li><a href='admin/currencies.php'>Manage Currencies</a></li>";
    echo "<li><a href='test_product_buttons.php'>Test Product Buttons</a></li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>
