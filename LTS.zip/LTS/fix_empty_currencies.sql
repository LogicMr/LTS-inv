-- Fix for empty currencies table causing foreign key constraint errors

-- Step 1: Create TSh currency with ID 1
INSERT INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 2: Verify TSh currency was created
SELECT '=== TSH CURRENCY CREATED ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE id = 1;

-- Step 3: Update all products to use TSh currency (ID 1)
UPDATE products SET currency_id = 1 WHERE currency_id IS NULL;

-- Step 4: Update any products with other currency_id values
UPDATE products SET currency_id = 1 WHERE currency_id != 1;

-- Step 5: Update sales
UPDATE sales SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 6: Update purchases  
UPDATE purchases SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 7: Update sale_items if table exists
UPDATE sale_items SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 8: Update purchase_items if table exists
UPDATE purchase_items SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 9: Final verification
SELECT '=== FIX COMPLETE ===' as info;
SELECT 'Products:' as table_name, currency_id, COUNT(*) as count FROM products GROUP BY currency_id;
SELECT 'Sales:' as table_name, currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;
SELECT 'Purchases:' as table_name, currency_id, COUNT(*) as count FROM purchases GROUP BY currency_id;
SELECT 'Final currencies:' as table_name, id, code, name, symbol, is_active, is_default FROM currencies;
