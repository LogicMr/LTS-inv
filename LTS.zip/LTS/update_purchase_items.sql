-- Check and add missing columns for purchase items
-- This script adds barcode and currency_id support to purchase_items table

-- Add barcode column if it doesn't exist
ALTER TABLE purchase_items 
ADD COLUMN IF NOT EXISTS barcode VARCHAR(100) NULL COMMENT 'Product barcode for purchase item';

-- Add currency_id column if it doesn't exist  
ALTER TABLE purchase_items
ADD COLUMN IF NOT EXISTS currency_id INT NULL COMMENT 'Currency ID for purchase item';

-- Add foreign key for currency_id if it doesn't exist
ALTER TABLE purchase_items 
ADD CONSTRAINT IF NOT EXISTS fk_purchase_items_currency 
FOREIGN KEY (currency_id) REFERENCES currencies(id) ON DELETE SET NULL;

-- Show updated structure
DESCRIBE purchase_items;
