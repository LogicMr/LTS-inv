<?php
/**
 * Temporary Login Fix
 * This allows plain text password for testing
 * REMOVE THIS IN PRODUCTION!
 */

// Include required files
require_once 'config/config.php';

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Temporarily allow plain text for admin
    if ($username === 'admin' && $password === 'admin123') {
        // Get admin user
        $sql = "SELECT * FROM users WHERE username = 'admin'";
        $user = fetchRow($sql);
        
        if ($user) {
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user'] = $user;
            $_SESSION['login_time'] = time();
            
            // Redirect to dashboard
            header('Location: manager/dashboard.php');
            exit;
        }
    }
    
    echo "<div style='color: red;'>Login failed</div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Temporary Login Fix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Temporary Login Fix</h3>
                    </div>
                    <div class="card-body">
                        <p class="text-warning">This is a temporary fix for testing. Use admin/admin123</p>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" name="username" class="form-control" value="admin" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                        </form>
                        
                        <hr>
                        <p><a href="debug_login.php">Debug Login</a></p>
                        <p><a href="auth/login.php">Go to Normal Login</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
