-- Update Admin Password Script
-- Run this in phpMyAdmin SQL tab after importing the database

-- Generate correct hash for 'admin123' and update the admin user
UPDATE users SET password = '$2y$10$8K1O9G2vZ5Q7X3Y6W8T9O9Q5v5h5h5h5h5h5h5h5h5h5h5h5h5h5h5h5h5' WHERE username = 'admin';

-- Verify the update
SELECT username, full_name, role_id, is_active FROM users WHERE username = 'admin';
