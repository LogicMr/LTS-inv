<?php
/**
 * Create Settings Table and Insert Defaults
 */
require_once __DIR__ . '/config/config.php';

echo "<h2>Creating Settings System</h2>";

try {
    // Create the system_settings table
    $createTableSQL = "
    CREATE TABLE IF NOT EXISTS `system_settings` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting_key` varchar(100) NOT NULL UNIQUE,
        `setting_value` text NOT NULL,
        `setting_type` enum('string', 'number', 'boolean', 'json') NOT NULL DEFAULT 'string',
        `setting_group` varchar(50) NOT NULL DEFAULT 'general',
        `description` text DEFAULT NULL,
        `is_editable` tinyint(1) NOT NULL DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_setting` (`setting_key`),
        KEY `idx_group` (`setting_group`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    
    if ($pdo->exec($createTableSQL)) {
        echo "<p style='color: green;'>✅ Settings table created successfully!</p>";
        
        // Insert default settings
        $defaultSettings = [
            ['store_name', 'Inventory Management System', 'string', 'general', 'Store or business name displayed throughout system'],
            ['default_currency', '1', 'number', 'general', 'Default currency ID for new records'],
            ['items_per_page', '20', 'number', 'general', 'Number of items displayed per page in lists'],
            ['company_address', '', 'string', 'general', 'Company address for receipts and documents'],
            ['company_phone', '', 'string', 'general', 'Company phone number for receipts and documents'],
            ['company_email', '', 'string', 'general', 'Company email for receipts and documents'],
            ['tax_rate', '0', 'number', 'general', 'Default tax rate percentage'],
            ['enable_tax', '0', 'boolean', 'general', 'Enable tax calculations on sales'],
            ['low_stock_threshold', '10', 'number', 'inventory', 'Alert when stock falls below this quantity'],
            ['expiry_warning_days', '30', 'number', 'inventory', 'Warn when products expire within this many days'],
            ['receipt_header', 'Thank you for your business!', 'string', 'receipt', 'Header text printed on receipts'],
            ['receipt_footer', 'Visit us again!', 'string', 'receipt', 'Footer text printed on receipts'],
            ['enable_email_notifications', '0', 'boolean', 'notifications', 'Enable email notifications for alerts'],
            ['backup_retention_days', '30', 'number', 'backup', 'Number of days to retain backup files'],
            ['enable_auto_backup', '0', 'boolean', 'backup', 'Enable automatic daily backups'],
            ['timezone', 'UTC', 'string', 'general', 'System timezone for date/time display'],
            ['date_format', 'Y-m-d', 'string', 'general', 'Default date format for display'],
            ['time_format', 'H:i:s', 'string', 'general', 'Default time format for display'],
            ['decimal_places', '2', 'number', 'general', 'Number of decimal places for currency'],
            ['thousands_separator', ',', 'string', 'general', 'Thousands separator for numbers'],
            ['decimal_separator', '.', 'string', 'general', 'Decimal separator for numbers']
        ];
        
        $insertStmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value, setting_type, setting_group, description) VALUES (?, ?, ?, ?, ?)");
        
        $successCount = 0;
        foreach ($defaultSettings as $setting) {
            if ($insertStmt->execute($setting)) {
                $successCount++;
            }
        }
        
        echo "<p style='color: green;'>✅ $successCount default settings inserted successfully!</p>";
        
        // Verify settings were inserted
        $count = $pdo->query("SELECT COUNT(*) as count FROM system_settings")->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p style='color: green;'>✅ Total settings in database: $count</p>";
        
        echo "<h3>✅ Settings System is Ready!</h3>";
        echo "<p><a href='admin/settings.php' target='_blank' style='font-size: 18px; color: #007bff;'>⚙️ Go to Settings Page</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ Error creating settings table!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
