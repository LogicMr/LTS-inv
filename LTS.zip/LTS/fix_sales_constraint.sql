-- Fix sales table currency constraint

-- Step 1: Verify TSh currency exists
SELECT '=== TSH CURRENCY STATUS ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE code = 'TZS';

-- Step 2: Check sales table currency_id values
SELECT '=== SALES CURRENCY VALUES ===' as info;
SELECT currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;

-- Step 3: Update sales with NULL currency_id to use TSh currency
UPDATE sales SET currency_id = 1 WHERE currency_id IS NULL;

-- Step 4: Update sales with invalid currency_id to use TSh currency
UPDATE sales SET currency_id = 1 WHERE currency_id NOT IN (SELECT id FROM currencies WHERE id = 1);

-- Step 5: Check updated result
SELECT '=== UPDATED SALES CURRENCY ===' as info;
SELECT currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;

-- Step 6: Test adding a sale with currency_id = 1
INSERT INTO sales (customer_name, total_amount, discount_amount, final_amount, payment_method, currency_id, created_at, updated_at) 
VALUES ('Test Customer', 100.00, 0.00, 100.00, 'cash', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 7: Verify test sale was added
SELECT '=== TEST SALE ADDED ===' as info;
SELECT id, customer_name, total_amount, final_amount, currency_id FROM sales WHERE customer_name = 'Test Customer';

-- Step 8: Clean up test sale
DELETE FROM sales WHERE customer_name = 'Test Customer';
