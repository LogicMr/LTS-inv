<?php
/**
 * Quick Password Hash Generator
 * This will generate the correct hash for admin123
 */

// Generate hash for admin123
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);

echo "Generated hash for 'admin123':<br>";
echo $hash . "<br><br>";

// Test the hash
if (password_verify($password, $hash)) {
    echo "✓ Hash verification successful<br>";
} else {
    echo "✗ Hash verification failed<br>";
}

// Create SQL update
echo "<br>SQL to update admin password:<br>";
echo "<code style='background: #f0f0f0; padding: 10px; display: block;'>";
echo "UPDATE users SET password = '$hash' WHERE username = 'admin';";
echo "</code>";
?>
