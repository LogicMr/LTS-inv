-- Check current state and fix sales constraint

-- Step 1: Check if TSh currency exists
SELECT '=== TSH CURRENCY CHECK ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE code = 'TZS';

-- Step 2: Check current sales currency_id values
SELECT '=== SALES CURRENCY STATUS ===' as info;
SELECT currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;

-- Step 3: Temporarily disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Step 4: Update all sales to use TSh currency
UPDATE sales SET currency_id = 1;

-- Step 5: Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Step 6: Verify the fix
SELECT '=== SALES CURRENCY FIXED ===' as info;
SELECT currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;

-- Step 7: Test adding a sale
INSERT INTO sales (customer_name, total_amount, discount_amount, final_amount, payment_method, currency_id, created_at, updated_at) 
VALUES ('Test Customer', 100.00, 0.00, 100.00, 'cash', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 8: Verify test sale was added
SELECT '=== TEST SALE SUCCESS ===' as info;
SELECT id, customer_name, total_amount, final_amount, currency_id FROM sales WHERE customer_name = 'Test Customer';

-- Step 9: Clean up test sale
DELETE FROM sales WHERE customer_name = 'Test Customer';
