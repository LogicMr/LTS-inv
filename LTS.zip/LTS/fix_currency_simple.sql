-- Fix foreign key constraints for TSh currency system

-- First, check if currencies table exists and has data
SELECT '=== CHECKING CURRENCIES ===' as info;
SELECT * FROM currencies;

-- Create TSh currency if it doesn't exist
INSERT IGNORE INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Set TSh as default currency
UPDATE currencies SET is_default = TRUE WHERE code = 'TZS';

-- Make all other currencies inactive
UPDATE currencies SET is_active = FALSE WHERE code != 'TZS';

-- Update all products to use TSh currency (ID 1)
UPDATE products SET currency_id = 1 WHERE currency_id IS NULL OR currency_id NOT IN (SELECT id FROM currencies WHERE is_active = TRUE);

-- Update all sales to use TSh currency
UPDATE sales SET currency_id = 1 WHERE currency_id IS NULL OR currency_id NOT IN (SELECT id FROM currencies WHERE is_active = TRUE);

-- Update all purchases to use TSh currency
UPDATE purchases SET currency_id = 1 WHERE currency_id IS NULL OR currency_id NOT IN (SELECT id FROM currencies WHERE is_active = TRUE);

-- Update all sale_items to use TSh currency if table exists
UPDATE sale_items SET currency_id = 1 WHERE currency_id IS NOT NULL AND currency_id NOT IN (SELECT id FROM currencies WHERE is_active = TRUE);

-- Update all purchase_items to use TSh currency if table exists
UPDATE purchase_items SET currency_id = 1 WHERE currency_id IS NOT NULL AND currency_id NOT IN (SELECT id FROM currencies WHERE is_active = TRUE);

-- Verify the fix
SELECT '=== FOREIGN KEY FIX COMPLETE ===' as status;
SELECT 'Products after fix:' as info;
SELECT currency_id, COUNT(*) as count FROM products GROUP BY currency_id;

SELECT 'Currencies after fix:' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies ORDER BY is_default DESC;
