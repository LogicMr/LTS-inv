<?php
/**
 * Quick Password Fix
 * This script will create the correct password hash for admin123
 */

// Plain text password
$plainPassword = 'admin123';

// Generate hash
$hash = password_hash($plainPassword, PASSWORD_DEFAULT, ['cost' => 10]);

echo "Plain password: " . $plainPassword . "\n";
echo "Generated hash: " . $hash . "\n";

// Test verification
if (password_verify($plainPassword, $hash)) {
    echo "Verification: SUCCESS\n";
} else {
    echo "Verification: FAILED\n";
}

// Create SQL update statement
echo "\nSQL Update Statement:\n";
echo "UPDATE users SET password = '" . $hash . "' WHERE username = 'admin';\n";
?>
