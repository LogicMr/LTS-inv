-- Fix supplier foreign key constraint issue

-- Step 1: Check if suppliers table exists and has data
SELECT '=== SUPPLIERS TABLE CHECK ===' as info;
SELECT COUNT(*) as supplier_count FROM suppliers;

-- Step 2: Show available suppliers
SELECT '=== AVAILABLE SUPPLIERS ===' as info;
SELECT id, name FROM suppliers LIMIT 5;

-- Step 3: Create a default supplier if none exist
INSERT IGNORE INTO suppliers (id, name, contact_person, phone, email, address, created_at, updated_at) 
VALUES (1, 'Default Supplier', 'Default Contact', '0000000000', 'default@supplier.com', 'Default Address', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 4: Verify default supplier exists
SELECT '=== DEFAULT SUPPLIER STATUS ===' as info;
SELECT id, name FROM suppliers WHERE id = 1;

-- Step 5: Update products with NULL supplier_id to use default supplier
UPDATE products SET supplier_id = 1 WHERE supplier_id IS NULL;

-- Step 6: Try to add a test product with supplier_id = 1
INSERT INTO products (name, category_id, barcode, cost_price, selling_price, quantity_in_stock, reorder_level, supplier_id, expiry_date, batch_number, description, is_active, currency_id) 
VALUES ('Test Product', 1, 'TEST123', 100.00, 150.00, 50, 10, 1, NULL, NULL, 'Test product for currency fix', 1, 1);

-- Step 7: Verify test product was added
SELECT '=== TEST PRODUCT ADDED ===' as info;
SELECT id, name, cost_price, selling_price, supplier_id, currency_id FROM products WHERE name = 'Test Product';
