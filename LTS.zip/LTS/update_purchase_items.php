<?php
/**
 * Update Purchase Items Database Structure
 * Adds barcode and currency_id columns if they don't exist
 */
require_once __DIR__ . '/config/config.php';

echo "=== Updating Purchase Items Table ===\n";

try {
    // Check if barcode column exists
    $barcodeCheck = fetchRow("SHOW COLUMNS FROM purchase_items LIKE 'barcode'");
    if (!$barcodeCheck) {
        echo "Adding barcode column...\n";
        executeNonQuery("ALTER TABLE purchase_items ADD COLUMN barcode VARCHAR(100) NULL COMMENT 'Product barcode for purchase item'");
        echo "✅ Barcode column added\n";
    } else {
        echo "✅ Barcode column already exists\n";
    }
    
    // Check if currency_id column exists
    $currencyCheck = fetchRow("SHOW COLUMNS FROM purchase_items LIKE 'currency_id'");
    if (!$currencyCheck) {
        echo "Adding currency_id column...\n";
        executeNonQuery("ALTER TABLE purchase_items ADD COLUMN currency_id INT NULL COMMENT 'Currency ID for purchase item'");
        echo "✅ Currency column added\n";
        
        // Add foreign key
        echo "Adding foreign key constraint...\n";
        executeNonQuery("ALTER TABLE purchase_items ADD CONSTRAINT fk_purchase_items_currency FOREIGN KEY (currency_id) REFERENCES currencies(id) ON DELETE SET NULL");
        echo "✅ Foreign key added\n";
    } else {
        echo "✅ Currency column already exists\n";
    }
    
    echo "\n=== Updated Structure ===\n";
    $columns = fetchAll("DESCRIBE purchase_items");
    foreach ($columns as $column) {
        echo "- {$column['Field']} ({$column['Type']}) {$column['Null']} {$column['Key']}\n";
    }
    
    echo "\n=== Update Complete ===\n";
    echo "Purchase items table is now ready for barcode and currency support!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
