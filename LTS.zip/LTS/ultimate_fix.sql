-- Final solution - currency_id column already exists

-- Step 1: Create TSh currency if it doesn't exist
INSERT IGNORE INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 2: Verify TSh currency exists
SELECT '=== TSH CURRENCY STATUS ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE code = 'TZS';

-- Step 3: Update NULL currency_id values first
UPDATE products SET currency_id = 1 WHERE currency_id IS NULL;

-- Step 4: Check result of NULL updates
SELECT '=== NULL UPDATE RESULT ===' as info;
SELECT COUNT(*) as updated_count FROM products WHERE currency_id = 1 AND currency_id IS NOT NULL;

-- Step 5: Try to update a few non-NULL values
UPDATE products SET currency_id = 1 WHERE currency_id != 1 LIMIT 5;

-- Step 6: Check final result
SELECT '=== FINAL RESULT ===' as info;
SELECT currency_id, COUNT(*) as count FROM products GROUP BY currency_id;

-- Step 7: Try to add a test product to verify fix
INSERT INTO products (name, category_id, cost_price, selling_price, quantity_in_stock, reorder_level, currency_id, created_at, updated_at) 
VALUES ('Test Product', 1, 100.00, 150.00, 50, 10, 1, 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
