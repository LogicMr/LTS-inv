-- Simplified constraint fix - no information_schema access needed

-- Step 1: Drop the foreign key constraint (try the known name)
ALTER TABLE products DROP FOREIGN KEY products_ibfk_3;

-- Step 2: Ensure TSh currency exists
INSERT IGNORE INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 3: Update all products to use TSh currency
UPDATE products SET currency_id = 1;

-- Step 4: Update all related tables
UPDATE sales SET currency_id = 1;
UPDATE purchases SET currency_id = 1;
UPDATE sale_items SET currency_id = 1;
UPDATE purchase_items SET currency_id = 1;

-- Step 5: Recreate the foreign key constraint
ALTER TABLE products 
ADD CONSTRAINT products_ibfk_3 
FOREIGN KEY (currency_id) REFERENCES currencies(id);

-- Step 6: Verify everything is fixed
SELECT '=== SIMPLIFIED FIX COMPLETE ===' as info;
SELECT 'Products:' as table_name, currency_id, COUNT(*) as count FROM products GROUP BY currency_id;
SELECT 'Sales:' as table_name, currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;
SELECT 'Currencies:' as table_name, id, code, name, symbol, is_active, is_default FROM currencies ORDER BY is_default DESC;
