<?php
/**
 * Generate Proper Hash for Database
 */
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);

// Create the exact SQL line
$sqlLine = "('admin', '$hash', 'System Administrator', 'admin@inventory.com', 1);";

echo "Copy this line into database.sql:\n";
echo $sqlLine;

// Also create the full INSERT statement
$fullInsert = "-- Insert default admin user (password: admin123)\n";
$fullInsert .= "INSERT INTO users (username, password, full_name, email, role_id) VALUES \n";
$fullInsert .= $sqlLine;

file_put_contents('admin_insert.sql', $fullInsert);
echo "\n\nSaved to admin_insert.sql";
?>
