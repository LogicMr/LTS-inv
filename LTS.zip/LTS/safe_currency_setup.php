<?php
/**
 * Safe Currency Setup
 * This script safely adds currency support without causing duplicate column errors
 */
require_once 'config/config.php';

echo "<h2>Safe Currency Setup</h2>";

try {
    // Step 1: Create currencies table
    $createCurrenciesTable = "
        CREATE TABLE IF NOT EXISTS currencies (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(3) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            symbol VARCHAR(10) NOT NULL,
            exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
            is_active BOOLEAN DEFAULT TRUE,
            is_default BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
    
    executeNonQuery($createCurrenciesTable);
    echo "<p style='color: green;'>✓ Currencies table created/verified</p>";
    
    // Step 2: Insert currencies safely
    $currencies = [
        ['USD', 'US Dollar', '$', 1.000000, true],
        ['EUR', 'Euro', '€', 0.850000, false],
        ['GBP', 'British Pound', '£', 0.730000, false],
        ['TZS', 'Tanzanian Shilling', 'TSh', 2315.000000, false],
        ['KES', 'Kenyan Shilling', 'KSh', 130.500000, false],
        ['UGX', 'Ugandan Shilling', 'UGX', 3725.000000, false],
        ['RWF', 'Rwandan Franc', 'RWF', 1250.000000, false],
        ['BIF', 'Burundian Franc', 'BIF', 2850.000000, false],
        ['ZAR', 'South African Rand', 'R', 18.500000, false],
        ['INR', 'Indian Rupee', '₹', 83.250000, false],
        ['CNY', 'Chinese Yuan', '¥', 7.250000, false],
        ['JPY', 'Japanese Yen', '¥', 149.750000, false]
    ];
    
    foreach ($currencies as $currency) {
        $sql = "INSERT IGNORE INTO currencies (code, name, symbol, exchange_rate, is_default) VALUES (?, ?, ?, ?, ?)";
        executeNonQuery($sql, $currency);
    }
    echo "<p style='color: green;'>✓ Currencies inserted/updated</p>";
    
    // Step 3: Check and add currency_id to products table
    $checkColumn = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                             WHERE TABLE_SCHEMA = DATABASE() 
                             AND TABLE_NAME = 'products' 
                             AND COLUMN_NAME = 'currency_id'");
    
    if ($checkColumn['count'] == 0) {
        executeNonQuery("ALTER TABLE products ADD COLUMN currency_id INT DEFAULT 1 AFTER selling_price");
        echo "<p style='color: green;'>✓ Added currency_id to products table</p>";
    } else {
        echo "<p style='color: orange;'>⚠ currency_id already exists in products table</p>";
    }
    
    // Step 4: Add foreign key for products.currency_id if needed
    try {
        executeNonQuery("ALTER TABLE products ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added foreign key for products.currency_id</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Foreign key already exists for products.currency_id</p>";
    }
    
    // Step 5: Update existing products to use default currency
    $defaultCurrency = fetchRow("SELECT id FROM currencies WHERE is_default = TRUE LIMIT 1");
    if ($defaultCurrency) {
        executeNonQuery("UPDATE products SET currency_id = ? WHERE currency_id IS NULL OR currency_id = 0", [$defaultCurrency['id']]);
        echo "<p style='color: green;'>✓ Updated existing products to use default currency</p>";
    }
    
    // Step 6: Add currency fields to sales table
    $checkSalesCurrency = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                                   WHERE TABLE_SCHEMA = DATABASE() 
                                   AND TABLE_NAME = 'sales' 
                                   AND COLUMN_NAME = 'currency_id'");
    
    if ($checkSalesCurrency['count'] == 0) {
        executeNonQuery("ALTER TABLE sales ADD COLUMN currency_id INT DEFAULT 1");
        executeNonQuery("ALTER TABLE sales ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000");
        echo "<p style='color: green;'>✓ Added currency fields to sales table</p>";
    } else {
        echo "<p style='color: orange;'>⚠ Currency fields already exist in sales table</p>";
    }
    
    // Step 7: Add foreign key for sales.currency_id if needed
    try {
        executeNonQuery("ALTER TABLE sales ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added foreign key for sales.currency_id</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Foreign key already exists for sales.currency_id</p>";
    }
    
    // Step 8: Add currency fields to purchases table
    $checkPurchasesCurrency = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                                       WHERE TABLE_SCHEMA = DATABASE() 
                                       AND TABLE_NAME = 'purchases' 
                                       AND COLUMN_NAME = 'currency_id'");
    
    if ($checkPurchasesCurrency['count'] == 0) {
        executeNonQuery("ALTER TABLE purchases ADD COLUMN currency_id INT DEFAULT 1");
        executeNonQuery("ALTER TABLE purchases ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000");
        echo "<p style='color: green;'>✓ Added currency fields to purchases table</p>";
    } else {
        echo "<p style='color: orange;'>⚠ Currency fields already exist in purchases table</p>";
    }
    
    // Step 9: Add foreign key for purchases.currency_id if needed
    try {
        executeNonQuery("ALTER TABLE purchases ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added foreign key for purchases.currency_id</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Foreign key already exists for purchases.currency_id</p>";
    }
    
    // Show results
    echo "<hr>";
    echo "<h3>Setup Complete!</h3>";
    
    $currencies = fetchAll("SELECT * FROM currencies ORDER BY is_default DESC, code");
    echo "<h4>Available Currencies:</h4>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Code</th><th>Name</th><th>Symbol</th><th>Exchange Rate</th><th>Default</th></tr>";
    foreach ($currencies as $currency) {
        echo "<tr>";
        echo "<td>{$currency['code']}</td>";
        echo "<td>{$currency['name']}</td>";
        echo "<td>{$currency['symbol']}</td>";
        echo "<td>" . number_format($currency['exchange_rate'], 6) . "</td>";
        echo "<td>" . ($currency['is_default'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check products with currency
    $productCount = fetchRow("SELECT COUNT(*) as count FROM products WHERE currency_id IS NOT NULL");
    echo "<p><strong>Products with currency:</strong> {$productCount['count']}</p>";
    
    echo "<hr>";
    echo "<h3>Next Steps:</h3>";
    echo "<ul>";
    echo "<li><a href='admin/currencies.php'>Manage Currencies</a> (update exchange rates)</li>";
    echo "<li><a href='manager/products.php'>Test Product Management</a> with currency selection</li>";
    echo "<li><a href='test_currency.php'>Test Currency Functions</a></li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>
