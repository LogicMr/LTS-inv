<?php
/**
 * Fix Admin Password
 * Run this script once to fix the admin password
 */

// Database connection
$host = 'localhost';
$dbname = 'inventory_system';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Generate correct password hash for "admin123"
    $plainPassword = 'admin123';
    $hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT, ['cost' => 10]);
    
    echo "Generated hash for 'admin123': " . $hashedPassword . "\n";
    
    // Update admin password
    $sql = "UPDATE users SET password = ? WHERE username = 'admin'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$hashedPassword]);
    
    echo "Admin password updated successfully!\n";
    
    // Verify the hash
    $verifySql = "SELECT password FROM users WHERE username = 'admin'";
    $verifyStmt = $pdo->query($verifySql);
    $user = $verifyStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify('admin123', $user['password'])) {
        echo "Password verification: SUCCESS\n";
    } else {
        echo "Password verification: FAILED\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
