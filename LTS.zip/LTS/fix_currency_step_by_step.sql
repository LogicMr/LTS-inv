-- Step-by-step fix for foreign key constraint

-- Step 1: Create TSh currency first
INSERT INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 2: Verify TSh currency exists
SELECT '=== TSH CURRENCY CREATED ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE id = 1;

-- Step 3: Update products with NULL currency_id first
UPDATE products SET currency_id = 1 WHERE currency_id IS NULL;

-- Step 4: Update products with invalid currency_id
UPDATE products SET currency_id = 1 WHERE currency_id NOT IN (SELECT id FROM currencies WHERE id = 1);

-- Step 5: Update sales
UPDATE sales SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 6: Update purchases  
UPDATE purchases SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 7: Update sale_items if table exists
UPDATE sale_items SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 8: Update purchase_items if table exists
UPDATE purchase_items SET currency_id = 1 WHERE currency_id IS NULL OR currency_id != 1;

-- Step 9: Verify the fix
SELECT '=== FIX COMPLETE ===' as info;
SELECT 'Products:' as table_name, currency_id, COUNT(*) as count FROM products GROUP BY currency_id;
SELECT 'Sales:' as table_name, currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;
SELECT 'Purchases:' as table_name, currency_id, COUNT(*) as count FROM purchases GROUP BY currency_id;
SELECT 'Currencies:' as table_name, id, code, name, symbol, is_active, is_default FROM currencies;
