-- Simplest possible solution

-- Step 1: Create TSh currency if it doesn't exist
INSERT IGNORE INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 2: Verify TSh currency exists
SELECT '=== TSH CURRENCY STATUS ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE code = 'TZS';

-- Step 3: Try to update products with a simple approach
-- First, try updating only NULL values
UPDATE products SET currency_id = 1 WHERE currency_id IS NULL;

-- Step 4: Check result
SELECT '=== UPDATE RESULT ===' as info;
SELECT currency_id, COUNT(*) as count FROM products GROUP BY currency_id;

-- Step 5: If NULL values were updated, try updating others
UPDATE products SET currency_id = 1 WHERE currency_id != 1 LIMIT 10;

-- Step 6: Check final result
SELECT '=== FINAL RESULT ===' as info;
SELECT currency_id, COUNT(*) as count FROM products GROUP BY currency_id;
