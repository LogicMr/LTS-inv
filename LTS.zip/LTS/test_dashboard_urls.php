<?php
/**
 * Test Dashboard URLs
 * This script tests the dashboard URL generation
 */
require_once 'config/config.php';

echo "<h2>Dashboard URL Test</h2>";

// Test getUserDashboard function for each role
$testRoles = [
    ['id' => 1, 'name' => 'Admin'],
    ['id' => 2, 'name' => 'Manager'],
    ['id' => 3, 'name' => 'Cashier']
];

echo "<h3>Dashboard Paths:</h3>";
foreach ($testRoles as $role) {
    // Mock user session
    $_SESSION['user'] = ['role_id' => $role['id']];
    
    $dashboardPath = getUserDashboard();
    $fullUrl = BASE_URL . '/' . $dashboardPath;
    
    echo "<p><strong>{$role['name']}:</strong> $dashboardPath</p>";
    echo "<p><strong>Full URL:</strong> <a href='$fullUrl'>$fullUrl</a></p>";
    echo "<hr>";
}

// Clear test session
unset($_SESSION['user']);

echo "<h3>Expected Results:</h3>";
echo "<ul>";
echo "<li>Admin: " . BASE_URL . "/admin/dashboard.php</li>";
echo "<li>Manager: " . BASE_URL . "/manager/dashboard.php</li>";
echo "<li>Cashier: " . BASE_URL . "/cashier/dashboard.php</li>";
echo "</ul>";

echo "<hr>";
echo "<p><a href='auth/login.php'>Test Login</a></p>";
echo "<p><a href='clear_session.php'>Clear Session</a></p>";
?>
