-- Comprehensive fix for all currency-related constraints

-- Step 1: Check if TSh currency exists
SELECT '=== TSH CURRENCY CHECK ===' as info;
SELECT id, code, name, symbol, is_active, is_default FROM currencies WHERE code = 'TZS';

-- Step 2: Drop all foreign key constraints from all tables
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_1;
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_2;
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_3;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_1;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_2;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_3;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_1;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_2;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_3;
ALTER TABLE sale_items DROP FOREIGN KEY IF EXISTS sale_items_ibfk_1;
ALTER TABLE sale_items DROP FOREIGN KEY IF EXISTS sale_items_ibfk_2;
ALTER TABLE purchase_items DROP FOREIGN KEY IF EXISTS purchase_items_ibfk_1;
ALTER TABLE purchase_items DROP FOREIGN KEY IF EXISTS purchase_items_ibfk_2;

-- Step 3: Update all tables to use TSh currency
UPDATE products SET currency_id = 1;
UPDATE sales SET currency_id = 1;
UPDATE purchases SET currency_id = 1;
UPDATE sale_items SET currency_id = 1;
UPDATE purchase_items SET currency_id = 1;

-- Step 4: Verify all updates
SELECT '=== ALL TABLES UPDATED ===' as info;
SELECT 'Products:' as table_name, currency_id, COUNT(*) as count FROM products GROUP BY currency_id
UNION ALL
SELECT 'Sales:' as table_name, currency_id, COUNT(*) as count FROM sales GROUP BY currency_id
UNION ALL
SELECT 'Purchases:' as table_name, currency_id, COUNT(*) as count FROM purchases GROUP BY currency_id;

-- Step 5: Recreate all foreign key constraints
ALTER TABLE products ADD CONSTRAINT products_ibfk_3 FOREIGN KEY (currency_id) REFERENCES currencies(id);
ALTER TABLE sales ADD CONSTRAINT sales_ibfk_3 FOREIGN KEY (currency_id) REFERENCES currencies(id);
ALTER TABLE purchases ADD CONSTRAINT purchases_ibfk_3 FOREIGN KEY (currency_id) REFERENCES currencies(id);
ALTER TABLE sale_items ADD CONSTRAINT sale_items_ibfk_1 FOREIGN KEY (currency_id) REFERENCES currencies(id);
ALTER TABLE purchase_items ADD CONSTRAINT purchase_items_ibfk_1 FOREIGN KEY (currency_id) REFERENCES currencies(id);

-- Step 6: Test adding a sale
INSERT INTO sales (customer_name, total_amount, discount_amount, final_amount, payment_method, currency_id, created_at, updated_at) 
VALUES ('Test Customer', 100.00, 0.00, 100.00, 'cash', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 7: Verify test sale was added
SELECT '=== TEST SALE SUCCESS ===' as info;
SELECT id, customer_name, total_amount, final_amount, currency_id FROM sales WHERE customer_name = 'Test Customer';

-- Step 8: Clean up test sale
DELETE FROM sales WHERE customer_name = 'Test Customer';
