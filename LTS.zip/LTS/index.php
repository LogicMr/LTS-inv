<?php
/**
 * Main Entry Point
 * Inventory Management System
 */

// Include required files
require_once __DIR__ . '/config/config.php';

// Always redirect to login page
redirect('auth/login.php');
?>
