# LTS Inventory Management System

## 📚 Documentation

All documentation has been moved to the **DOC** folder for better organization.

### 📖 Quick Access

**🚀 Quick Start:**
- **URL**: `http://localhost/LTS/`
- **Username**: `admin`
- **Password**: `admin123`

### 📁 Documentation Files

See the **[DOC](./DOC/)** folder for complete documentation:

- **[INSTALL.md](./DOC/INSTALL.md)** - Complete installation guide
- **[README.md](./DOC/README.md)** - System overview and features
- **[SYSTEM_DOCUMENTATION.md](./DOC/SYSTEM_DOCUMENTATION.md)** - Technical documentation
- **[DEPLOYMENT.md](./DOC/DEPLOYMENT.md)** - Production deployment guide
- **[DOCUMENTATION_INDEX.md](./DOC/DOCUMENTATION_INDEX.md)** - Documentation overview

### 🆕 Latest Features (Version 1.0.0+)

- **🎨 Enhanced Reporting**: Professional PDF export with multi-currency support
- **📱 Mobile Support**: Cross-device login and responsive design
- **🌐 Production Ready**: Works with any hosting provider
- **💰 Multi-Currency**: Advanced currency management system
- **🔐 Enhanced Security**: Modern security features

### 🌐 Hosting Compatibility

Works with ALL hosting providers:
- ✅ cPanel (Bluehost, GoDaddy, HostGator)
- ✅ Plesk (SiteGround, A2 Hosting)
- ✅ DirectAdmin (InMotion Hosting)
- ✅ VPS/Dedicated (DigitalOcean, Vultr, Linode)
- ✅ Cloud Platforms (AWS, Google Cloud, Azure)

**Zero Configuration Required** - Upload and use immediately!

---

**📖 For complete documentation, see the [DOC](./DOC/) folder.**
