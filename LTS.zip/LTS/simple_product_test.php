<?php
/**
 * Simple Product Test
 * Test basic product operations without currency complexity
 */
require_once 'config/config.php';

echo "<h2>Simple Product Test</h2>";

// Test 1: Check if we can fetch products
echo "<h3>Test 1: Fetch Products</h3>";
try {
    $products = fetchAll("SELECT id, name FROM products LIMIT 3");
    echo "<p>✅ Can fetch products: " . count($products) . " found</p>";
    
    if (count($products) > 0) {
        foreach ($products as $product) {
            echo "<p>- Product ID {$product['id']}: " . htmlspecialchars($product['name']) . "</p>";
        }
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 2: Check get_product.php endpoint
echo "<h3>Test 2: get_product.php Endpoint</h3>";
if (count($products) > 0) {
    $testProductId = $products[0]['id'];
    echo "<p>Testing product ID: $testProductId</p>";
    
    try {
        $product = fetchRow("SELECT * FROM products WHERE id = ?", [$testProductId]);
        if ($product) {
            echo "<p>✅ Product data found</p>";
            echo "<pre>" . print_r($product, true) . "</pre>";
        } else {
            echo "<p>❌ Product not found</p>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error: " . $e->getMessage() . "</p>";
    }
}

// Test 3: Simulate form submission
echo "<h3>Test 3: Form Simulation</h3>";
if (isset($product)) {
    echo "<p>Simulating edit form data:</p>";
    
    $testData = [
        'id' => $product['id'],
        'name' => $product['name'],
        'category_id' => $product['category_id'],
        'cost_price' => $product['cost_price'],
        'selling_price' => $product['selling_price'],
        'quantity_in_stock' => $product['quantity_in_stock'],
        'reorder_level' => $product['reorder_level'],
        'currency_id' => $product['currency_id'] ?? 1
    ];
    
    echo "<pre>" . print_r($testData, true) . "</pre>";
    
    // Test validation
    if (function_exists('validateRequired')) {
        $required = ['id', 'name', 'category_id', 'cost_price', 'selling_price', 'quantity_in_stock', 'reorder_level', 'currency_id'];
        $errors = validateRequired($required, $testData);
        
        if (empty($errors)) {
            echo "<p>✅ Validation passed</p>";
        } else {
            echo "<p>❌ Validation errors: " . implode(', ', $errors) . "</p>";
        }
    } else {
        echo "<p>❌ validateRequired function not found</p>";
    }
}

// Test 4: Check JavaScript dependencies
echo "<h3>Test 4: Dependencies Check</h3>";
echo "<p>Check these in browser:</p>";
echo "<ul>";
echo "<li>Bootstrap 5.3.0+ loaded?</li>";
echo "<li>No JavaScript errors in console?</li>";
echo "<li>editProduct() function defined?</li>";
echo "<li>deleteProduct() function defined?</li>";
echo "</ul>";

echo "<h3>Manual Tests:</h3>";
echo "<ol>";
echo "<li>Open <a href='manager/products.php'>Products Page</a></li>";
echo "<li>Press F12 for developer tools</li>";
echo "<li>Click Edit button - check console</li>";
echo "<li>Click Delete button - check console</li>";
echo "<li>Check Network tab for AJAX calls</li>";
echo "</ol>";

echo "<h3>Common Issues:</h3>";
echo "<ul>";
echo "<li><strong>Bootstrap not loaded:</strong> Modals won't work</li>";
echo "<li><strong>JavaScript errors:</strong> Functions won't execute</li>";
echo "<li><strong>AJAX failures:</strong> Can't load product data</li>";
echo "<li><strong>Missing fields:</strong> Form validation fails</li>";
echo "</ul>";
?>
