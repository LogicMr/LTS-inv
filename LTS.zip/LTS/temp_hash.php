<?php
// Generate correct hash for admin123
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
echo $hash;
?>
