-- Safe Currency Setup Script
-- This script checks for existing columns and only adds what's missing

-- Create currencies table if it doesn't exist
CREATE TABLE IF NOT EXISTS currencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(3) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
    is_active BOOLEAN DEFAULT TRUE,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert currencies (ignore duplicates)
INSERT IGNORE INTO currencies (code, name, symbol, exchange_rate, is_default) VALUES
('USD', 'US Dollar', '$', 1.000000, TRUE),
('EUR', 'Euro', '€', 0.850000, FALSE),
('GBP', 'British Pound', '£', 0.730000, FALSE),
('TZS', 'Tanzanian Shilling', 'TSh', 2315.000000, FALSE),
('KES', 'Kenyan Shilling', 'KSh', 130.500000, FALSE),
('UGX', 'Ugandan Shilling', 'UGX', 3725.000000, FALSE),
('RWF', 'Rwandan Franc', 'RWF', 1250.000000, FALSE),
('BIF', 'Burundian Franc', 'BIF', 2850.000000, FALSE),
('ZAR', 'South African Rand', 'R', 18.500000, FALSE),
('INR', 'Indian Rupee', '₹', 83.250000, FALSE),
('CNY', 'Chinese Yuan', '¥', 7.250000, FALSE),
('JPY', 'Japanese Yen', '¥', 149.750000, FALSE);

-- Safely add currency_id to products table (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'products' 
     AND COLUMN_NAME = 'currency_id') > 0,
    'SELECT "currency_id already exists in products table" as message;',
    'ALTER TABLE products ADD COLUMN currency_id INT DEFAULT 1 AFTER selling_price'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Safely add foreign key for products.currency_id (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'products' 
     AND CONSTRAINT_NAME = 'products_ibfk_3') > 0,
    'SELECT "Foreign key already exists for products.currency_id" as message;',
    'ALTER TABLE products ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Update existing products to use default currency (only if needed)
UPDATE products SET currency_id = (SELECT id FROM currencies WHERE is_default = TRUE LIMIT 1) 
WHERE currency_id IS NULL OR currency_id = 0;

-- Safely add currency fields to sales table
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'sales' 
     AND COLUMN_NAME = 'currency_id') > 0,
    'SELECT "currency_id already exists in sales table" as message;',
    'ALTER TABLE sales ADD COLUMN currency_id INT DEFAULT 1'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'sales' 
     AND COLUMN_NAME = 'exchange_rate') > 0,
    'SELECT "exchange_rate already exists in sales table" as message;',
    'ALTER TABLE sales ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Safely add foreign key for sales.currency_id
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'sales' 
     AND CONSTRAINT_NAME = 'sales_ibfk_3') > 0,
    'SELECT "Foreign key already exists for sales.currency_id" as message;',
    'ALTER TABLE sales ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Safely add currency fields to purchases table
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'purchases' 
     AND COLUMN_NAME = 'currency_id') > 0,
    'SELECT "currency_id already exists in purchases table" as message;',
    'ALTER TABLE purchases ADD COLUMN currency_id INT DEFAULT 1'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'purchases' 
     AND COLUMN_NAME = 'exchange_rate') > 0,
    'SELECT "exchange_rate already exists in purchases table" as message;',
    'ALTER TABLE purchases ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Safely add foreign key for purchases.currency_id
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
     WHERE TABLE_SCHEMA = DATABASE() 
     AND TABLE_NAME = 'purchases' 
     AND CONSTRAINT_NAME = 'purchases_ibfk_3') > 0,
    'SELECT "Foreign key already exists for purchases.currency_id" as message;',
    'ALTER TABLE purchases ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify setup
SELECT 'Setup Complete!' as status;
SELECT COUNT(*) as currency_count FROM currencies;
SELECT code, name, symbol, is_default FROM currencies ORDER BY is_default DESC, code;
