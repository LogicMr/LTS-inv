-- Check and drop existing constraints by name

-- Step 1: Check what constraints actually exist
SELECT '=== EXISTING CONSTRAINTS ===' as info;
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM 
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE 
    TABLE_SCHEMA = 'inventory_system' 
    AND REFERENCED_TABLE_NAME = 'currencies'
ORDER BY TABLE_NAME, CONSTRAINT_NAME;

-- Step 2: Drop constraints that reference currencies (using actual names)
-- Try common constraint names
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_3;
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_1;
ALTER TABLE products DROP FOREIGN KEY IF EXISTS products_ibfk_2;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_1;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_2;
ALTER TABLE sales DROP FOREIGN KEY IF EXISTS sales_ibfk_3;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_1;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_2;
ALTER TABLE purchases DROP FOREIGN KEY IF EXISTS purchases_ibfk_3;
ALTER TABLE sale_items DROP FOREIGN KEY IF EXISTS sale_items_ibfk_1;
ALTER TABLE sale_items DROP FOREIGN KEY IF EXISTS sale_items_ibfk_2;
ALTER TABLE purchase_items DROP FOREIGN KEY IF EXISTS purchase_items_ibfk_1;
ALTER TABLE purchase_items DROP FOREIGN KEY IF EXISTS purchase_items_ibfk_2;

-- Step 3: Ensure TSh currency exists
INSERT IGNORE INTO currencies (id, code, name, symbol, exchange_rate, is_active, is_default, created_at, updated_at) 
VALUES (1, 'TZS', 'Tanzanian Shilling', 'TSh', 1.000000, TRUE, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- Step 4: Update all tables to use TSh currency
UPDATE products SET currency_id = 1;
UPDATE sales SET currency_id = 1;
UPDATE purchases SET currency_id = 1;
UPDATE sale_items SET currency_id = 1;
UPDATE purchase_items SET currency_id = 1;

-- Step 5: Recreate constraints with standard naming
ALTER TABLE products 
ADD CONSTRAINT products_ibfk_3 
FOREIGN KEY (currency_id) REFERENCES currencies(id);

ALTER TABLE sales 
ADD CONSTRAINT sales_ibfk_2 
FOREIGN KEY (currency_id) REFERENCES currencies(id);

ALTER TABLE purchases 
ADD CONSTRAINT purchases_ibfk_3 
FOREIGN KEY (currency_id) REFERENCES currencies(id);

-- Step 6: Verify everything is fixed
SELECT '=== FINAL FIX COMPLETE ===' as info;
SELECT 'Products:' as table_name, currency_id, COUNT(*) as count FROM products GROUP BY currency_id;
SELECT 'Sales:' as table_name, currency_id, COUNT(*) as count FROM sales GROUP BY currency_id;
SELECT 'Currencies:' as table_name, id, code, name, symbol, is_active, is_default FROM currencies ORDER BY is_default DESC;
