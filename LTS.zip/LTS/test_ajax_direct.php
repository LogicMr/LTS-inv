<?php
/**
 * Direct AJAX Test
 * Test the get_product.php endpoint directly
 */
require_once 'config/config.php';

echo "<h2>Direct AJAX Test</h2>";

if (!isLoggedIn()) {
    echo "<p>Please <a href='auth/login.php'>login</a> first</p>";
    exit;
}

$user = getCurrentUser();
$userRole = getRoleName($user['role_id']);
echo "<p>Logged in as: {$user['full_name']} ($userRole)</p>";

// Get a test product
$testProduct = fetchRow("SELECT id, name FROM products LIMIT 1");

if ($testProduct) {
    $productId = $testProduct['id'];
    echo "<h3>Testing Product ID: $productId ({$testProduct['name']})</h3>";
    
    echo "<h4>Direct URL Test:</h4>";
    $url = BASE_URL . "/manager/get_product.php?id=$productId";
    echo "<p><a href='$url' target='_blank'>$url</a></p>";
    
    // Test the endpoint by making a direct call
    echo "<h4>Direct PHP Test:</h4>";
    
    // Save current buffer
    ob_start();
    
    try {
        // Simulate the exact same request
        $_GET['id'] = $productId;
        
        // Include the file directly
        include 'manager/get_product.php';
        
        $output = ob_get_contents();
        ob_end_clean();
        
        echo "<h5>Output Analysis:</h5>";
        echo "<p>Output length: " . strlen($output) . " characters</p>";
        echo "<p>First 100 characters: " . htmlspecialchars(substr($output, 0, 100)) . "</p>";
        
        // Check if it's JSON
        $trimmed = trim($output);
        if (substr($trimmed, 0, 1) === '{' && substr($trimmed, -1) === '}') {
            echo "<p style='color: green;'>✅ Output starts and ends like JSON</p>";
            
            $jsonData = json_decode($output, true);
            if ($jsonData !== null) {
                echo "<p style='color: green;'>✅ Valid JSON</p>";
                echo "<pre>" . json_encode($jsonData, JSON_PRETTY_PRINT) . "</pre>";
            } else {
                echo "<p style='color: orange;'>⚠ JSON parsing failed</p>";
                echo "<p>Last error: " . json_last_error_msg() . "</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ Output is NOT JSON</p>";
            
            // Check for HTML
            if (strpos($output, '<!DOCTYPE') !== false) {
                echo "<p style='color: red;'>❌ Contains HTML DOCTYPE</p>";
            }
            if (strpos($output, '<html') !== false) {
                echo "<p style='color: red;'>❌ Contains HTML tag</p>";
            }
            if (strpos($output, 'Warning') !== false) {
                echo "<p style='color: orange;'>⚠ Contains PHP Warning</p>";
            }
            if (strpos($output, 'Fatal') !== false) {
                echo "<p style='color: red;'>❌ Contains PHP Fatal Error</p>";
            }
        }
        
        // Show full output for debugging
        echo "<h5>Full Output:</h5>";
        echo "<textarea style='width: 100%; height: 200px;'>" . htmlspecialchars($output) . "</textarea>";
        
    } catch (Exception $e) {
        ob_end_clean();
        echo "<p style='color: red;'>❌ Exception: " . $e->getMessage() . "</p>";
    }
    
    // Reset $_GET
    unset($_GET['id']);
    
} else {
    echo "<p>No products found to test</p>";
}

echo "<h3>Manual Test:</h3>";
echo "<p>Open browser console and run:</p>";
echo "<pre>";
echo "// Test AJAX call directly
fetch('" . BASE_URL . "/manager/get_product.php?id=" . ($testProduct['id'] ?? 1) . "')
  .then(response => {
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    return response.text();
  })
  .then(text => {
    console.log('Raw response:', text);
    try {
      const json = JSON.parse(text);
      console.log('Parsed JSON:', json);
    } catch(e) {
      console.error('JSON parse error:', e);
      console.log('Response is not JSON - it might be HTML');
    }
  })
  .catch(error => console.error('Fetch error:', error));
</pre>";

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Click the direct URL link above</li>";
echo "<li>Check if it shows JSON or HTML</li>";
echo "<li>Run the manual JavaScript test in console</li>";
echo "<li>Report what you see in the output</li>";
echo "</ol>";
?>
