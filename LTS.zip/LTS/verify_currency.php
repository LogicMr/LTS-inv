<?php
/**
 * Verify Currency Setup
 * This script verifies that the currency support is working correctly
 */
require_once 'config/config.php';

echo "<h2>Verify Currency Setup</h2>";

try {
    // Check currencies table
    $currencies = fetchAll("SELECT * FROM currencies ORDER BY is_default DESC, code");
    echo "<h3>Currencies Table Status:</h3>";
    echo "<p><strong>Total Currencies:</strong> " . count($currencies) . "</p>";
    
    if (count($currencies) > 0) {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>Code</th><th>Name</th><th>Symbol</th><th>Exchange Rate</th><th>Active</th><th>Default</th></tr>";
        foreach ($currencies as $currency) {
            echo "<tr>";
            echo "<td><strong>{$currency['code']}</strong></td>";
            echo "<td>{$currency['name']}</td>";
            echo "<td>{$currency['symbol']}</td>";
            echo "<td>" . number_format($currency['exchange_rate'], 6) . "</td>";
            echo "<td>" . ($currency['is_active'] ? '✓' : '✗') . "</td>";
            echo "<td>" . ($currency['is_default'] ? '✓' : '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red;'>❌ No currencies found</p>";
    }
    
    // Check products table currency column
    echo "<h3>Products Table Status:</h3>";
    $checkColumn = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                             WHERE TABLE_SCHEMA = DATABASE() 
                             AND TABLE_NAME = 'products' 
                             AND COLUMN_NAME = 'currency_id'");
    
    if ($checkColumn['count'] > 0) {
        echo "<p style='color: green;'>✅ currency_id column exists in products table</p>";
        
        // Check products with currency
        $productsWithCurrency = fetchRow("SELECT COUNT(*) as count FROM products WHERE currency_id IS NOT NULL");
        echo "<p><strong>Products with currency set:</strong> {$productsWithCurrency['count']}</p>";
        
        // Show sample products with currency
        $sampleProducts = fetchAll("SELECT p.name, p.cost_price, p.selling_price, cur.code as currency_code, cur.symbol as currency_symbol 
                                    FROM products p 
                                    LEFT JOIN currencies cur ON p.currency_id = cur.id 
                                    LIMIT 5");
        
        if (count($sampleProducts) > 0) {
            echo "<h4>Sample Products:</h4>";
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>Product</th><th>Cost Price</th><th>Selling Price</th><th>Currency</th></tr>";
            foreach ($sampleProducts as $product) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($product['name']) . "</td>";
                echo "<td>" . formatCurrency($product['cost_price'], $product['currency_id']) . "</td>";
                echo "<td>" . formatCurrency($product['selling_price'], $product['currency_id']) . "</td>";
                echo "<td>{$product['currency_code']} ({$product['currency_symbol']})</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p style='color: red;'>❌ currency_id column missing from products table</p>";
    }
    
    // Check sales and purchases tables
    echo "<h3>Sales & Purchases Tables Status:</h3>";
    
    $salesCurrency = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                              WHERE TABLE_SCHEMA = DATABASE() 
                              AND TABLE_NAME = 'sales' 
                              AND COLUMN_NAME = 'currency_id'");
    
    $purchasesCurrency = fetchRow("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS 
                                  WHERE TABLE_SCHEMA = DATABASE() 
                                  AND TABLE_NAME = 'purchases' 
                                  AND COLUMN_NAME = 'currency_id'");
    
    echo "<p>Sales table currency_id: " . ($salesCurrency['count'] > 0 ? '✅' : '❌') . "</p>";
    echo "<p>Purchases table currency_id: " . ($purchasesCurrency['count'] > 0 ? '✅' : '❌') . "</p>";
    
    // Test currency functions
    echo "<h3>Currency Functions Test:</h3>";
    $defaultCurrency = getDefaultCurrency();
    if ($defaultCurrency) {
        echo "<p><strong>Default Currency:</strong> {$defaultCurrency['code']} ({$defaultCurrency['symbol']})</p>";
        
        $testAmount = 100.50;
        echo "<p><strong>Test Amount:</strong> ";
        foreach ($currencies as $currency) {
            if ($currency['is_active']) {
                $formatted = formatCurrency($testAmount, $currency['id']);
                echo "{$formatted} | ";
            }
        }
        echo "</p>";
    }
    
    echo "<hr>";
    echo "<h3>Setup Status:</h3>";
    
    $allGood = true;
    if (count($currencies) === 0) $allGood = false;
    if ($checkColumn['count'] === 0) $allGood = false;
    if ($salesCurrency['count'] === 0) $allGood = false;
    if ($purchasesCurrency['count'] === 0) $allGood = false;
    
    if ($allGood) {
        echo "<p style='color: green; font-size: 18px;'>🎉 Currency setup is COMPLETE and working!</p>";
        echo "<h3>Next Steps:</h3>";
        echo "<ul>";
        echo "<li><a href='admin/currencies.php'>Manage Currencies</a> - Update exchange rates</li>";
        echo "<li><a href='manager/products.php'>Add Products</a> - Test currency selection</li>";
        echo "<li><a href='test_currency.php'>Test Currency Functions</a></li>";
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>⚠ Setup is partially complete. Some components may be missing.</p>";
        echo "<p><a href='safe_currency_setup.php'>Run Safe Setup Again</a></p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>
