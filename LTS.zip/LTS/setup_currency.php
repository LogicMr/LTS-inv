<?php
/**
 * Add Currency Support to Database
 * This script adds multi-currency functionality to the inventory system
 */
require_once 'config/config.php';

echo "<h2>Add Currency Support</h2>";

try {
    // Create currencies table
    $createCurrenciesTable = "
        CREATE TABLE IF NOT EXISTS currencies (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(3) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            symbol VARCHAR(10) NOT NULL,
            exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
            is_active BOOLEAN DEFAULT TRUE,
            is_default BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
    
    executeNonQuery($createCurrenciesTable);
    echo "<p style='color: green;'>✓ Currencies table created/verified</p>";
    
    // Insert common currencies
    $insertCurrencies = "
        INSERT INTO currencies (code, name, symbol, exchange_rate, is_default) VALUES
        ('USD', 'US Dollar', '$', 1.000000, TRUE),
        ('EUR', 'Euro', '€', 0.850000, FALSE),
        ('GBP', 'British Pound', '£', 0.730000, FALSE),
        ('TZS', 'Tanzanian Shilling', 'TSh', 2315.000000, FALSE),
        ('KES', 'Kenyan Shilling', 'KSh', 130.500000, FALSE),
        ('UGX', 'Ugandan Shilling', 'UGX', 3725.000000, FALSE),
        ('RWF', 'Rwandan Franc', 'RWF', 1250.000000, FALSE),
        ('BIF', 'Burundian Franc', 'BIF', 2850.000000, FALSE),
        ('ZAR', 'South African Rand', 'R', 18.500000, FALSE),
        ('INR', 'Indian Rupee', '₹', 83.250000, FALSE),
        ('CNY', 'Chinese Yuan', '¥', 7.250000, FALSE),
        ('JPY', 'Japanese Yen', '¥', 149.750000, FALSE)
        ON DUPLICATE KEY UPDATE 
            name = VALUES(name), 
            symbol = VALUES(symbol), 
            exchange_rate = VALUES(exchange_rate)";
    
    executeNonQuery($insertCurrencies);
    echo "<p style='color: green;'>✓ Common currencies inserted/updated</p>";
    
    // Add currency_id to products table
    try {
        executeNonQuery("ALTER TABLE products ADD COLUMN currency_id INT DEFAULT 1 AFTER selling_price");
        echo "<p style='color: green;'>✓ Added currency_id to products table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ currency_id column already exists in products table</p>";
    }
    
    // Add foreign key for products.currency_id
    try {
        executeNonQuery("ALTER TABLE products ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added foreign key for products.currency_id</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Foreign key already exists for products.currency_id</p>";
    }
    
    // Update existing products to use default currency
    $defaultCurrency = fetchRow("SELECT id FROM currencies WHERE is_default = TRUE LIMIT 1");
    if ($defaultCurrency) {
        executeNonQuery("UPDATE products SET currency_id = ? WHERE currency_id IS NULL", [$defaultCurrency['id']]);
        echo "<p style='color: green;'>✓ Updated existing products to use default currency</p>";
    }
    
    // Add currency fields to sales table
    try {
        executeNonQuery("ALTER TABLE sales ADD COLUMN currency_id INT DEFAULT 1");
        executeNonQuery("ALTER TABLE sales ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000");
        executeNonQuery("ALTER TABLE sales ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added currency fields to sales table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Currency fields already exist in sales table</p>";
    }
    
    // Add currency fields to purchases table
    try {
        executeNonQuery("ALTER TABLE purchases ADD COLUMN currency_id INT DEFAULT 1");
        executeNonQuery("ALTER TABLE purchases ADD COLUMN exchange_rate DECIMAL(10,6) DEFAULT 1.000000");
        executeNonQuery("ALTER TABLE purchases ADD FOREIGN KEY (currency_id) REFERENCES currencies(id)");
        echo "<p style='color: green;'>✓ Added currency fields to purchases table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Currency fields already exist in purchases table</p>";
    }
    
    // Show results
    echo "<hr>";
    echo "<h3>Setup Complete!</h3>";
    
    $currencies = fetchAll("SELECT * FROM currencies ORDER BY is_default DESC, code");
    echo "<h4>Available Currencies:</h4>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Code</th><th>Name</th><th>Symbol</th><th>Exchange Rate</th><th>Default</th></tr>";
    foreach ($currencies as $currency) {
        echo "<tr>";
        echo "<td>{$currency['code']}</td>";
        echo "<td>{$currency['name']}</td>";
        echo "<td>{$currency['symbol']}</td>";
        echo "<td>" . number_format($currency['exchange_rate'], 6) . "</td>";
        echo "<td>" . ($currency['is_default'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<hr>";
    echo "<h3>Next Steps:</h3>";
    echo "<ul>";
    echo "<li><a href='admin/currencies.php'>Manage Currencies</a> (update exchange rates)</li>";
    echo "<li><a href='manager/products.php'>Test Product Management</a> with currency selection</li>";
    echo "<li><a href='test_currency.php'>Test Currency Functions</a></li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>
