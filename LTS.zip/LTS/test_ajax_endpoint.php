<?php
/**
 * Test AJAX Endpoint
 * This script tests the get_product.php AJAX endpoint
 */
require_once 'config/config.php';

echo "<h2>Test AJAX Endpoint</h2>";

// Test 1: Direct access to get_product.php
echo "<h3>Test 1: Direct Endpoint Access</h3>";

if (!isLoggedIn()) {
    echo "<p>❌ Not logged in. Please <a href='auth/login.php'>login first</a></p>";
    exit;
}

$user = getCurrentUser();
$userRole = getRoleName($user['role_id']);
echo "<p>Logged in as: {$user['full_name']} ($userRole)</p>";

// Get a test product
$testProduct = fetchRow("SELECT id, name FROM products LIMIT 1");

if ($testProduct) {
    $productId = $testProduct['id'];
    echo "<p>Testing with product ID: $productId ({$testProduct['name']})</p>";
    
    // Test the endpoint directly
    echo "<h4>Direct URL Test:</h4>";
    $url = BASE_URL . "/manager/get_product.php?id=$productId";
    echo "<p><a href='$url' target='_blank'>$url</a></p>";
    
    // Simulate the AJAX call
    echo "<h4>Simulated AJAX Response:</h4>";
    
    // Check permissions
    if ($userRole !== 'Admin' && $userRole !== 'Manager') {
        echo "<p style='color: orange;'>⚠ User role '$userRole' may not have permission</p>";
    }
    
    // Get product data
    $product = fetchRow("SELECT * FROM products WHERE id = ?", [$productId]);
    
    if ($product) {
        echo "<p style='color: green;'>✅ Product data found</p>";
        echo "<pre>";
        echo json_encode($product, JSON_PRETTY_PRINT);
        echo "</pre>";
        
        // Check if currency data is included
        if (isset($product['currency_id'])) {
            echo "<p style='color: green;'>✅ Currency ID included: {$product['currency_id']}</p>";
        } else {
            echo "<p style='color: orange;'>⚠ Currency ID missing</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Product not found</p>";
    }
    
} else {
    echo "<p>No products found to test with</p>";
}

// Test 2: Check for common issues
echo "<h3>Test 2: Common Issues Check</h3>";

echo "<h4>Authentication:</h4>";
echo "<p>isLoggedIn(): " . (isLoggedIn() ? '✅' : '❌') . "</p>";
echo "<p>getCurrentUser(): " . (getCurrentUser() ? '✅' : '❌') . "</p>";

echo "<h4>Permissions:</h4>";
echo "<p>User Role: $userRole</p>";
echo "<p>Can manage products: " . (($userRole === 'Admin' || $userRole === 'Manager') ? '✅' : '❌') . "</p>";

echo "<h4>Database:</h4>";
try {
    $count = fetchRow("SELECT COUNT(*) as count FROM products");
    echo "<p>Products table: ✅ ({$count['count']} records)</p>";
} catch (Exception $e) {
    echo "<p>Products table: ❌ (" . $e->getMessage() . ")</p>";
}

echo "<h3>Test 3: JavaScript Debug</h3>";
echo "<p>Open browser console and run:</p>";
echo "<pre>";
echo "// Test AJAX call directly
fetch('" . BASE_URL . "/manager/get_product.php?id=" . ($testProduct['id'] ?? 1) . "')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));
</pre>";

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Test the direct link above</li>";
echo "<li>Check if it returns JSON (not HTML)</li>";
echo "<li>If it works, test the edit button on products page</li>";
echo "<li>Check browser console for remaining errors</li>";
echo "</ol>";

echo "<p><a href='manager/products.php'>Back to Products Page</a></p>";
?>
